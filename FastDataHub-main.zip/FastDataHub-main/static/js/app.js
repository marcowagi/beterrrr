// ========== Global App Functions ==========

// Toast notification system
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer') || createToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icon = getToastIcon(type);
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas ${icon}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close" onclick="closeToast(this)">&times;</button>
    `;
    
    container.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        closeToast(toast.querySelector('.toast-close'));
    }, 5000);
    
    // Animate in
    setTimeout(() => toast.classList.add('show'), 100);
}

function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
    return container;
}

function getToastIcon(type) {
    const icons = {
        'success': 'fa-check-circle',
        'error': 'fa-exclamation-circle', 
        'warning': 'fa-exclamation-triangle',
        'info': 'fa-info-circle'
    };
    return icons[type] || icons.info;
}

function closeToast(button) {
    const toast = button.closest('.toast');
    if (toast) {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }
}

// Loading overlay functions
function showLoadingOverlay(message = 'جاري التحميل...') {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.querySelector('p').textContent = message;
        overlay.classList.remove('hidden');
    }
}

function hideLoadingOverlay() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.add('hidden');
    }
}

// System toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    initializeSystemToggle();
});

function initializeSystemToggle() {
    const toggleButton = document.getElementById('systemToggle');
    const toggleText = document.getElementById('toggleText');
    
    if (!toggleButton || !toggleText) return;
    
    // Load current system status
    loadSystemStatus();
    
    toggleButton.addEventListener('click', function() {
        toggleSystemStatus();
    });
}

function loadSystemStatus() {
    fetch('/api/dashboard/stats')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateSystemToggleUI(data.data.system_status === 'RUNNING');
            }
        })
        .catch(error => {
            console.error('Error loading system status:', error);
        });
}

function toggleSystemStatus() {
    const toggleButton = document.getElementById('systemToggle');
    toggleButton.disabled = true;
    
    fetch('/api/system/toggle', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateSystemToggleUI(data.system_enabled);
            showToast(data.message, 'success');
        } else {
            showToast('فشل في تغيير حالة النظام', 'error');
        }
    })
    .catch(error => {
        console.error('Error toggling system:', error);
        showToast('خطأ في تغيير حالة النظام', 'error');
    })
    .finally(() => {
        toggleButton.disabled = false;
    });
}

function updateSystemToggleUI(isRunning) {
    const toggleButton = document.getElementById('systemToggle');
    const toggleText = document.getElementById('toggleText');
    
    if (!toggleButton || !toggleText) return;
    
    if (isRunning) {
        toggleButton.className = 'btn btn-toggle active';
        toggleText.innerHTML = '<i class="fas fa-play"></i><span>يعمل</span>';
    } else {
        toggleButton.className = 'btn btn-toggle inactive';
        toggleText.innerHTML = '<i class="fas fa-stop"></i><span>متوقف</span>';
    }
}

// Format number with commas
function formatNumber(num) {
    return new Intl.NumberFormat('en-US').format(num);
}

// Format currency
function formatCurrency(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

// Format percentage
function formatPercentage(value, decimals = 2) {
    return `${value >= 0 ? '+' : ''}${value.toFixed(decimals)}%`;
}

// Debounce function for API calls
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Copy to clipboard function
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('تم النسخ إلى الحافظة', 'success');
    }).catch(() => {
        showToast('فشل في النسخ', 'error');
    });
}

// Animate counter numbers
function animateCounter(element, targetValue, duration = 1000) {
    const startValue = parseFloat(element.textContent.replace(/[^0-9.-]/g, '')) || 0;
    const increment = (targetValue - startValue) / (duration / 16);
    let currentValue = startValue;
    
    const timer = setInterval(() => {
        currentValue += increment;
        
        if ((increment > 0 && currentValue >= targetValue) || 
            (increment < 0 && currentValue <= targetValue)) {
            currentValue = targetValue;
            clearInterval(timer);
        }
        
        element.textContent = formatCurrency(currentValue);
    }, 16);
}

// Validate form inputs
function validateForm(form) {
    const inputs = form.querySelectorAll('[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('error');
            isValid = false;
        } else {
            input.classList.remove('error');
        }
    });
    
    return isValid;
}

// Handle API errors globally
function handleApiError(error, customMessage = null) {
    console.error('API Error:', error);
    
    let message = customMessage || 'حدث خطأ غير متوقع';
    
    if (error.response) {
        // Server responded with error
        message = error.response.data?.message || `خطأ ${error.response.status}`;
    } else if (error.request) {
        // Network error
        message = 'خطأ في الاتصال بالخادم';
    }
    
    showToast(message, 'error');
}

// Check if element is in viewport
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Smooth scroll to element
function scrollToElement(element, offset = 0) {
    const targetPosition = element.offsetTop - offset;
    window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
    });
}

// Generate random ID
function generateId(length = 8) {
    return Math.random().toString(36).substring(2, length + 2);
}

// Local storage helpers
const Storage = {
    set: function(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (e) {
            console.error('Storage set error:', e);
            return false;
        }
    },
    
    get: function(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (e) {
            console.error('Storage get error:', e);
            return defaultValue;
        }
    },
    
    remove: function(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (e) {
            console.error('Storage remove error:', e);
            return false;
        }
    }
};

// Date formatting
function formatDate(date, format = 'short') {
    const d = new Date(date);
    
    const formats = {
        'short': { day: '2-digit', month: '2-digit', year: '2-digit' },
        'long': { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' },
        'time': { hour: '2-digit', minute: '2-digit', second: '2-digit' }
    };
    
    return d.toLocaleDateString('ar-SA', formats[format] || formats.short);
}

// WebSocket connection handler (for real-time updates)
class WebSocketManager {
    constructor(url) {
        this.url = url;
        this.socket = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.handlers = new Map();
    }
    
    connect() {
        try {
            this.socket = new WebSocket(this.url);
            
            this.socket.onopen = () => {
                console.log('WebSocket connected');
                this.reconnectAttempts = 0;
                this.emit('connected');
            };
            
            this.socket.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.emit(data.type, data.payload);
                } catch (e) {
                    console.error('WebSocket message parse error:', e);
                }
            };
            
            this.socket.onclose = () => {
                console.log('WebSocket disconnected');
                this.emit('disconnected');
                this.attemptReconnect();
            };
            
            this.socket.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.emit('error', error);
            };
            
        } catch (e) {
            console.error('WebSocket connection error:', e);
            this.attemptReconnect();
        }
    }
    
    attemptReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            setTimeout(() => {
                console.log(`Reconnecting... attempt ${this.reconnectAttempts}`);
                this.connect();
            }, this.reconnectDelay * this.reconnectAttempts);
        }
    }
    
    on(event, handler) {
        if (!this.handlers.has(event)) {
            this.handlers.set(event, []);
        }
        this.handlers.get(event).push(handler);
    }
    
    emit(event, data = null) {
        if (this.handlers.has(event)) {
            this.handlers.get(event).forEach(handler => handler(data));
        }
    }
    
    send(data) {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(data));
        }
    }
    
    disconnect() {
        if (this.socket) {
            this.socket.close();
            this.socket = null;
        }
    }
}

// Initialize WebSocket for real-time updates (if available)
// const wsManager = new WebSocketManager(`ws://${window.location.host}/ws`);
// wsManager.connect();

// Export for use in other scripts
window.App = {
    showToast,
    hideLoadingOverlay,
    showLoadingOverlay,
    formatCurrency,
    formatNumber,
    formatPercentage,
    Storage,
    WebSocketManager
};