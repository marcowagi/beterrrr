from flask import render_template, jsonify, request, make_response
from app import app
from excel_manager import ExcelDataManager
import random
import os
from datetime import datetime, timedelta

# إنشاء مدير بيانات Excel
excel_manager = ExcelDataManager()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/settings')
def settings():
    return render_template('settings.html')

# === API Routes ===

@app.route('/api/dashboard/stats')
def dashboard_stats():
    """إحصائيات الصفحة الرئيسية"""
    
    try:
        # محاكاة البيانات الحية
        total_balance = random.uniform(120000, 130000)
        daily_profit = random.uniform(2500, 3200)
        daily_profit_percentage = (daily_profit / total_balance) * 100
        
        active_trades = random.randint(2, 5)
        available_opportunities = random.randint(8, 15)
        
        # جلب حالة النظام من إعدادات Excel
        settings = excel_manager.get_settings()
        system_status = 'RUNNING' if settings.get('system_enabled', False) else 'STOPPED'
        
        response = make_response(jsonify({
            'success': True,
            'data': {
                'total_balance': round(total_balance, 2),
                'daily_profit': round(daily_profit, 2),
                'daily_profit_percentage': round(daily_profit_percentage, 2),
                'active_trades': active_trades,
                'available_opportunities': available_opportunities,
                'system_status': system_status
            }
        }))
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        print(f"Error in dashboard_stats: {e}")
        response = make_response(jsonify({'success': False, 'error': str(e)}))
        response.headers['Content-Type'] = 'application/json'
        return response

@app.route('/api/exchanges/status')
def exchanges_status():
    """حالة المنصات"""
    
    try:
        # منصات نشطة (API مربوط)
        active_exchanges = [
            {'name': 'Binance', 'status': 'CONNECTED', 'response_time': 45, 'last_update': '14:32'},
            {'name': 'OKX', 'status': 'CONNECTED', 'response_time': 52, 'last_update': '14:32'},
            {'name': 'KuCoin', 'status': 'READ_ONLY', 'response_time': 78, 'last_update': '14:31'}
        ]
        
        # منصات بيانات فقط
        data_only_exchanges = [
            {'name': 'Bybit', 'status': 'DATA_ONLY', 'response_time': 38, 'last_update': '14:32'},
            {'name': 'Gate.io', 'status': 'DATA_ONLY', 'response_time': 63, 'last_update': '14:32'},
            {'name': 'Huobi', 'status': 'DATA_ONLY', 'response_time': 89, 'last_update': '14:31'}
        ]
        
        response = make_response(jsonify({
            'success': True,
            'data': {
                'active_exchanges': active_exchanges,
                'data_only_exchanges': data_only_exchanges
            }
        }))
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        print(f"Error in exchanges_status: {e}")
        response = make_response(jsonify({'success': False, 'error': str(e)}))
        response.headers['Content-Type'] = 'application/json'
        return response

@app.route('/api/opportunities/best')
def best_opportunities():
    """أفضل الفرص المتاحة"""
    
    try:
        pairs = ['BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'ADA/USDT', 'SOL/USDT']
        exchanges = ['Binance', 'OKX', 'KuCoin', 'Bybit', 'Gate.io']
        
        opportunities = []
        for i in range(6):  # أفضل 6 فرص
            pair = random.choice(pairs)
            buy_exchange = random.choice(exchanges)
            sell_exchange = random.choice([ex for ex in exchanges if ex != buy_exchange])
            
            profit_pct = random.uniform(0.15, 1.2)
            estimated_profit = random.uniform(100, 800)
            
            opportunity_data = {
                'id': f'opp_{i+1}',
                'pair': pair,
                'buy_exchange': buy_exchange,
                'sell_exchange': sell_exchange,
                'profit_percentage': round(profit_pct, 2),
                'estimated_profit_usd': round(estimated_profit, 2),
                'confidence': random.randint(75, 95),
                'volume_available': random.randint(5000, 25000)
            }
            
            # حفظ الفرصة في Excel
            excel_manager.add_opportunity({
                'pair': pair,
                'buy_exchange': buy_exchange,
                'sell_exchange': sell_exchange,
                'spread_percentage': profit_pct,
                'net_profit_percentage': profit_pct,
                'estimated_volume': opportunity_data['volume_available'],
                'confidence_score': opportunity_data['confidence']
            })
            
            opportunities.append(opportunity_data)
        
        # ترتيب حسب الربح
        opportunities.sort(key=lambda x: x['profit_percentage'], reverse=True)
        
        response = make_response(jsonify({
            'success': True,
            'data': opportunities
        }))
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        print(f"Error in best_opportunities: {e}")
        response = make_response(jsonify({'success': False, 'error': str(e)}))
        response.headers['Content-Type'] = 'application/json'
        return response

@app.route('/api/settings/arbitrage', methods=['GET', 'POST'])
def arbitrage_settings():
    """إعدادات الأربيتراج"""
    
    if request.method == 'GET':
        # جلب الإعدادات من Excel
        settings = excel_manager.get_settings()
        
        return jsonify({
            'success': True,
            'data': {
                'scan_frequency': settings.get('scan_frequency', 3),
                'min_profit_entry': settings.get('min_profit_entry', 0.15),
                'stop_loss_limit': settings.get('stop_loss_limit', -0.05),
                'base_trade_amount': settings.get('base_trade_amount', 1000.0),
                'profit_multiplier_25': settings.get('profit_multiplier_25', 1.5),
                'profit_multiplier_50': settings.get('profit_multiplier_50', 2.0),
                'profit_multiplier_100': settings.get('profit_multiplier_100', 3.0),
                'max_trade_amount': settings.get('max_trade_amount', 5000.0),
                'max_concurrent_trades': settings.get('max_concurrent_trades', 5),
                'daily_loss_limit': settings.get('daily_loss_limit', 500.0),
                'max_transfer_attempts': settings.get('max_transfer_attempts', 3),
                'transfer_retry_delay': settings.get('transfer_retry_delay', 30),
                'emergency_sell_enabled': settings.get('emergency_sell_enabled', True),
                'system_enabled': settings.get('system_enabled', False)
            }
        })
    
    else:  # POST
        # تحديث الإعدادات في Excel
        data = request.json
        
        if data:
            for key, value in data.items():
                excel_manager.update_setting(key, value)
        
        return jsonify({'success': True, 'message': 'تم حفظ الإعدادات بنجاح في Excel'})

@app.route('/api/system/toggle', methods=['POST'])
def toggle_system():
    """تشغيل/إيقاف النظام"""
    
    settings = excel_manager.get_settings()
    current_status = settings.get('system_enabled', False)
    new_status = not current_status
    
    # تحديث الحالة في Excel
    excel_manager.update_setting('system_enabled', new_status)
    
    status = 'تم تشغيل النظام' if new_status else 'تم إيقاف النظام'
    
    return jsonify({
        'success': True,
        'system_enabled': new_status,
        'message': status
    })

@app.route('/api/exchanges/connect', methods=['POST'])
def connect_exchange():
    """ربط منصة جديدة"""
    
    data = request.get_json() or {}
    exchange_name = data.get('exchange_name', '')
    api_key = data.get('api_key', '')
    api_secret = data.get('api_secret', '')
    
    # محاكاة اختبار الاتصال
    connection_success = random.choice([True, True, True, False])  # 75% نجاح
    
    # البحث عن المنصة في Excel أو إضافتها
    exchanges = excel_manager.get_exchanges()
    exchange_exists = any(ex['Name'] == exchange_name for ex in exchanges)
    
    if not exchange_exists:
        excel_manager.add_exchange({
            'name': exchange_name,
            'display_name': exchange_name.title(),
            'connection_status': 'DISABLED',
            'permissions': '',
            'is_enabled': False
        })
    
    # تحديث بيانات المنصة
    if connection_success:
        excel_manager.update_exchange(exchange_name, {
            'api_key_encrypted': f"encrypted_{api_key}",
            'api_secret_encrypted': f"encrypted_{api_secret}",
            'connection_status': 'CONNECTED',
            'permissions': 'read,trade',
            'last_test_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'is_enabled': True,
            'error_message': ''
        })
    else:
        excel_manager.update_exchange(exchange_name, {
            'connection_status': 'ERROR',
            'error_message': 'خطأ في المصادقة - تحقق من المفاتيح'
        })
    
    return jsonify({
        'success': connection_success,
        'message': 'تم ربط المنصة بنجاح وحفظها في Excel' if connection_success else 'فشل في ربط المنصة'
    })

@app.route('/api/exchanges/test/<exchange_name>')
def test_exchange(exchange_name):
    """اختبار اتصال منصة"""
    
    # البحث عن المنصة في Excel
    exchanges = excel_manager.get_exchanges()
    exchange = next((ex for ex in exchanges if ex['Name'] == exchange_name), None)
    
    if not exchange:
        return jsonify({'success': False, 'message': 'المنصة غير موجودة'})
    
    # محاكاة اختبار الاتصال
    test_success = random.choice([True, True, False])  # 66% نجاح
    
    if test_success:
        excel_manager.update_exchange(exchange_name, {
            'connection_status': 'CONNECTED',
            'last_test_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'error_message': ''
        })
        message = 'الاتصال سليم'
        status = 'CONNECTED'
    else:
        excel_manager.update_exchange(exchange_name, {
            'connection_status': 'ERROR',
            'error_message': 'انقطع الاتصال مؤقتاً'
        })
        message = 'فشل في الاتصال'
        status = 'ERROR'
    
    return jsonify({
        'success': test_success,
        'status': status,
        'message': message
    })

@app.route('/api/reports/daily')
def daily_report():
    """تقرير يومي"""
    date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    
    report_path = excel_manager.create_daily_report(date)
    
    if report_path:
        return jsonify({
            'success': True,
            'message': 'تم إنشاء التقرير اليومي بنجاح',
            'report_path': report_path
        })
    else:
        return jsonify({
            'success': False,
            'message': 'فشل في إنشاء التقرير'
        })

@app.route('/api/data/export')
def export_data():
    """تصدير جميع البيانات"""
    try:
        # تنسيق جميع ملفات Excel
        for file_path in excel_manager.files.values():
            if os.path.exists(file_path):
                excel_manager.format_excel_file(file_path)
        
        return jsonify({
            'success': True,
            'message': 'تم تصدير وتنسيق جميع البيانات بنجاح',
            'files': list(excel_manager.files.keys())
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'خطأ في التصدير: {str(e)}'
        })

# === Routes للصفحات الثابتة ===
@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy', 
        'timestamp': datetime.utcnow().isoformat(),
        'storage': 'Excel files',
        'data_manager': 'ExcelDataManager'
    })