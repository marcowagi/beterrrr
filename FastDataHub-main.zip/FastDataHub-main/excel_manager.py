import os
import pandas as pd
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

class ExcelDataManager:
    def __init__(self, data_dir="data"):
        """مدير بيانات Excel مع تنسيق احترافي"""
        self.data_dir = data_dir
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
        
        # ملفات البيانات
        self.files = {
            'exchanges': f'{data_dir}/exchanges.xlsx',
            'trading_pairs': f'{data_dir}/trading_pairs.xlsx', 
            'settings': f'{data_dir}/arbitrage_settings.xlsx',
            'opportunities': f'{data_dir}/opportunities.xlsx',
            'balances': f'{data_dir}/balances.xlsx',
            'trades': f'{data_dir}/trades.xlsx'
        }
        
        # إنشاء الملفات الأساسية إذا لم تكن موجودة
        self._initialize_files()
    
    def _initialize_files(self):
        """إنشاء ملفات Excel الأساسية بتنسيق احترافي"""
        
        # ملف المنصات
        if not os.path.exists(self.files['exchanges']):
            exchanges_data = pd.DataFrame(columns=[
                'ID', 'Name', 'Display_Name', 'API_Key', 'API_Secret',
                'Connection_Status', 'Last_Test_Time', 'Permissions', 
                'Error_Message', 'Is_Enabled', 'Created_At'
            ])
            exchanges_data.to_excel(self.files['exchanges'], index=False)
        
        # ملف الإعدادات
        if not os.path.exists(self.files['settings']):
            settings_data = pd.DataFrame([
                {'Parameter': 'scan_frequency', 'Value': 3, 'Description': 'تكرار المسح (ثواني)', 'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
                {'Parameter': 'min_profit_entry', 'Value': 0.15, 'Description': 'الحد الأدنى للربح للدخول (%)', 'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
                {'Parameter': 'stop_loss_limit', 'Value': -0.05, 'Description': 'حد وقف الخسارة (%)', 'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
                {'Parameter': 'base_trade_amount', 'Value': 1000.0, 'Description': 'مبلغ التداول الأساسي (USD)', 'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
                {'Parameter': 'max_trade_amount', 'Value': 5000.0, 'Description': 'الحد الأقصى للتداول (USD)', 'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
                {'Parameter': 'max_concurrent_trades', 'Value': 5, 'Description': 'الحد الأقصى للصفقات المتزامنة', 'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
                {'Parameter': 'daily_loss_limit', 'Value': 500.0, 'Description': 'حد الخسارة اليومية (USD)', 'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
                {'Parameter': 'system_enabled', 'Value': False, 'Description': 'النظام مفعل', 'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            ])
            settings_data.to_excel(self.files['settings'], index=False)
        
        # ملف أزواج التداول
        if not os.path.exists(self.files['trading_pairs']):
            pairs_data = pd.DataFrame(columns=[
                'ID', 'Symbol', 'Base_Asset', 'Quote_Asset', 'Is_Enabled', 'Category'
            ])
            pairs_data.to_excel(self.files['trading_pairs'], index=False)
        
        # ملف الفرص
        if not os.path.exists(self.files['opportunities']):
            opportunities_data = pd.DataFrame(columns=[
                'ID', 'Pair', 'Buy_Exchange', 'Sell_Exchange', 'Buy_Price', 
                'Sell_Price', 'Spread_Percentage', 'Net_Profit_Percentage', 
                'Estimated_Volume', 'Confidence_Score', 'Status', 'Created_At'
            ])
            opportunities_data.to_excel(self.files['opportunities'], index=False)
        
        # ملف الأرصدة
        if not os.path.exists(self.files['balances']):
            balances_data = pd.DataFrame(columns=[
                'ID', 'Exchange', 'Asset', 'Available', 'Locked', 'Last_Updated'
            ])
            balances_data.to_excel(self.files['balances'], index=False)
        
        # ملف الصفقات
        if not os.path.exists(self.files['trades']):
            trades_data = pd.DataFrame(columns=[
                'ID', 'Opportunity_ID', 'Trade_Amount', 'Status', 'Buy_Order_ID',
                'Sell_Order_ID', 'Transfer_TX_Hash', 'Transfer_Attempts', 
                'Realized_PnL', 'Fees_Paid', 'Created_At', 'Completed_At'
            ])
            trades_data.to_excel(self.files['trades'], index=False)
    
    # === وظائف المنصات ===
    def get_exchanges(self):
        """جلب جميع المنصات"""
        try:
            df = pd.read_excel(self.files['exchanges'])
            return df.to_dict('records') if not df.empty else []
        except Exception as e:
            print(f"خطأ في جلب المنصات: {e}")
            return []
    
    def add_exchange(self, exchange_data):
        """إضافة منصة جديدة"""
        try:
            df = pd.read_excel(self.files['exchanges'])
            
            # البحث عن آخر ID
            new_id = df['ID'].max() + 1 if not df.empty and 'ID' in df.columns else 1
            
            # إضافة البيانات الجديدة
            new_exchange = {
                'ID': new_id,
                'Name': exchange_data.get('name', ''),
                'Display_Name': exchange_data.get('display_name', ''),
                'API_Key': exchange_data.get('api_key_encrypted', ''),
                'API_Secret': exchange_data.get('api_secret_encrypted', ''),
                'Connection_Status': exchange_data.get('connection_status', 'DISABLED'),
                'Last_Test_Time': exchange_data.get('last_test_time', ''),
                'Permissions': exchange_data.get('permissions', ''),
                'Error_Message': exchange_data.get('error_message', ''),
                'Is_Enabled': exchange_data.get('is_enabled', False),
                'Created_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # إضافة الصف الجديد
            df = pd.concat([df, pd.DataFrame([new_exchange])], ignore_index=True)
            df.to_excel(self.files['exchanges'], index=False)
            return new_id
            
        except Exception as e:
            print(f"خطأ في إضافة المنصة: {e}")
            return None
    
    def update_exchange(self, exchange_name, updates):
        """تحديث بيانات منصة"""
        try:
            df = pd.read_excel(self.files['exchanges'])
            
            # البحث عن المنصة بالاسم
            mask = df['Name'] == exchange_name
            
            if mask.any():
                # تحديث البيانات
                for field, value in updates.items():
                    if field == 'connection_status':
                        df.loc[mask, 'Connection_Status'] = value
                    elif field == 'last_test_time':
                        df.loc[mask, 'Last_Test_Time'] = value
                    elif field == 'error_message':
                        df.loc[mask, 'Error_Message'] = value
                    elif field == 'is_enabled':
                        df.loc[mask, 'Is_Enabled'] = value
                    elif field == 'api_key_encrypted':
                        df.loc[mask, 'API_Key'] = value
                    elif field == 'api_secret_encrypted':
                        df.loc[mask, 'API_Secret'] = value
                    elif field == 'permissions':
                        df.loc[mask, 'Permissions'] = value
                
                df.to_excel(self.files['exchanges'], index=False)
                return True
            
            return False
            
        except Exception as e:
            print(f"خطأ في تحديث المنصة: {e}")
            return False
    
    # === وظائف الإعدادات ===
    def get_settings(self):
        """جلب إعدادات النظام"""
        try:
            df = pd.read_excel(self.files['settings'])
            settings = {}
            
            for _, row in df.iterrows():
                settings[row['Parameter']] = row['Value']
            
            return settings
        except Exception as e:
            print(f"خطأ في جلب الإعدادات: {e}")
            return {}
    
    def update_setting(self, key, value):
        """تحديث إعداد معين"""
        try:
            df = pd.read_excel(self.files['settings'])
            
            # البحث عن الإعداد وتحديثه
            mask = df['Parameter'] == key
            
            if mask.any():
                df.loc[mask, 'Value'] = value
                df.loc[mask, 'Updated_At'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            else:
                # إضافة إعداد جديد
                new_setting = pd.DataFrame([{
                    'Parameter': key,
                    'Value': value,
                    'Description': '',
                    'Updated_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }])
                df = pd.concat([df, new_setting], ignore_index=True)
            
            df.to_excel(self.files['settings'], index=False)
            return True
            
        except Exception as e:
            print(f"خطأ في تحديث الإعداد: {e}")
            return False
    
    # === وظائف الفرص ===
    def add_opportunity(self, opportunity_data):
        """إضافة فرصة جديدة"""
        try:
            df = pd.read_excel(self.files['opportunities'])
            
            # البحث عن آخر ID
            new_id = df['ID'].max() + 1 if not df.empty and 'ID' in df.columns else 1
            
            new_opportunity = {
                'ID': new_id,
                'Pair': opportunity_data.get('pair', ''),
                'Buy_Exchange': opportunity_data.get('buy_exchange', ''),
                'Sell_Exchange': opportunity_data.get('sell_exchange', ''),
                'Buy_Price': opportunity_data.get('buy_price', 0),
                'Sell_Price': opportunity_data.get('sell_price', 0),
                'Spread_Percentage': opportunity_data.get('spread_percentage', 0),
                'Net_Profit_Percentage': opportunity_data.get('net_profit_percentage', 0),
                'Estimated_Volume': opportunity_data.get('estimated_volume', 0),
                'Confidence_Score': opportunity_data.get('confidence_score', 0),
                'Status': opportunity_data.get('status', 'DETECTED'),
                'Created_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            df = pd.concat([df, pd.DataFrame([new_opportunity])], ignore_index=True)
            df.to_excel(self.files['opportunities'], index=False)
            return new_id
            
        except Exception as e:
            print(f"خطأ في إضافة الفرصة: {e}")
            return None
    
    def get_recent_opportunities(self, limit=10):
        """جلب الفرص الأخيرة"""
        try:
            df = pd.read_excel(self.files['opportunities'])
            
            if df.empty:
                return []
            
            # ترتيب حسب التاريخ وإرجاع العدد المطلوب
            df_sorted = df.sort_values('Created_At', ascending=False).head(limit)
            return df_sorted.to_dict('records')
            
        except Exception as e:
            print(f"خطأ في جلب الفرص: {e}")
            return []
    
    # === تقارير يومية ===
    def create_daily_report(self, date=None):
        """إنشاء تقرير يومي منسق"""
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
        
        try:
            # إنشاء تقرير بصيغة Excel مع تنسيق احترافي
            with pd.ExcelWriter(f"{self.data_dir}/daily_report_{date}.xlsx", engine='openpyxl') as writer:
                
                # ملخص اليوم
                summary_data = pd.DataFrame([
                    {'المؤشر': 'إجمالي الأرصدة', 'القيمة': '125,000', 'الوحدة': 'USD', 'الملاحظات': 'جميع المنصات'},
                    {'المؤشر': 'عدد الفرص المكتشفة', 'القيمة': '47', 'الوحدة': 'فرصة', 'الملاحظات': 'خلال اليوم'},
                    {'المؤشر': 'عدد الصفقات المنفذة', 'القيمة': '12', 'الوحدة': 'صفقة', 'الملاحظات': 'مكتملة'},
                    {'المؤشر': 'إجمالي الأرباح', 'القيمة': '3,250', 'الوحدة': 'USD', 'الملاحظات': 'صافي'},
                    {'المؤشر': 'نسبة النجاح', 'القيمة': '91.7%', 'الوحدة': '', 'الملاحظات': '11 من 12'}
                ])
                summary_data.to_excel(writer, sheet_name=f'ملخص_{date}', index=False)
                
                # الفرص المكتشفة اليوم
                opportunities_df = pd.read_excel(self.files['opportunities'])
                today_opportunities = opportunities_df[opportunities_df['Created_At'].str.startswith(date)] if not opportunities_df.empty else pd.DataFrame()
                today_opportunities.to_excel(writer, sheet_name='الفرص_اليوم', index=False)
            
            return f"{self.data_dir}/daily_report_{date}.xlsx"
            
        except Exception as e:
            print(f"خطأ في إنشاء التقرير: {e}")
            return None
    
    def format_excel_file(self, file_path):
        """تنسيق ملف Excel بشكل احترافي"""
        try:
            wb = load_workbook(file_path)
            
            for ws in wb.worksheets:
                # تنسيق عنوان الجدول
                header_fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
                header_font = Font(color="FFFFFF", bold=True, size=11)
                
                # تطبيق التنسيق على الصف الأول
                for cell in ws[1]:
                    cell.fill = header_fill
                    cell.font = header_font
                    cell.alignment = Alignment(horizontal='center', vertical='center')
                
                # ضبط عرض الأعمدة
                for column in ws.columns:
                    max_length = 0
                    column_letter = get_column_letter(column[0].column)
                    
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    
                    adjusted_width = min(max_length + 2, 30)
                    ws.column_dimensions[column_letter].width = adjusted_width
                
                # تجميد الصف الأول
                ws.freeze_panes = "A2"
            
            wb.save(file_path)
            return True
            
        except Exception as e:
            print(f"خطأ في تنسيق الملف: {e}")
            return False